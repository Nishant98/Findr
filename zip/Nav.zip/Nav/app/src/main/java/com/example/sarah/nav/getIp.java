package com.example.sarah.nav;

public class getIp {

    public String ip = "http://192.168.0.103";

    public String getIp(){
        return  ip;
    }

}
