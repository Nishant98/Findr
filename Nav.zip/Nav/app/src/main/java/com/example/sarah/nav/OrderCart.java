package com.example.sarah.nav;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class OrderCart extends AppCompatActivity {
    OrderAdapter orderAdapter;
    ArrayList<ModelFood> foodList;
    RecyclerView recyclerView1;

    SessionManager sessionManager;
    String email="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        foodList = new ArrayList<>();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.ordercart);


        sessionManager = new SessionManager(getApplicationContext());
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetails();
        email = user.get(sessionManager.EMAIL);

        recyclerView1 = findViewById(R.id.rvorder);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        RecyclerView.LayoutManager rvlayoutmanager = linearLayoutManager;
        recyclerView1.setLayoutManager(rvlayoutmanager);

        getData();
    }



    public void getData(){
        RequestQueue requestQueue = Volley.newRequestQueue(OrderCart.this);

        getIp ip = new getIp();
        String del = ip.getIp();
        String URL = ""+del+":8080/getOrdered";

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("email", email);
        } catch (Exception e) {
            e.printStackTrace();
        }

        final String requestBody = jsonObject.toString();
        Log.d("str", "str is" + requestBody);

        ConnectionManager.sendData(requestBody, requestQueue, URL, new ConnectionManager.VolleyCallback() {
            @Override
            public void onSuccessResponse(String result) {
                Log.d("result order =", "" + result);

               //result = result.replaceAll("\'", "");
                if (result != null) {
                    try {
                        JSONArray jsonArray = new JSONArray(result);
                        Log.d("jsonAray", "" + jsonArray);
                        Log.d("Jsonarray ka  size", "" + jsonArray.length());
                        int i;
                        for (i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                            String restaurant_name = null, category = null, imgname = null, price  = null, rid = null;
                            try {
                                restaurant_name = jsonObject1.getString("restaurant_name");
                                category = jsonObject1.getString("category");
                                imgname = jsonObject1.getString("image");
                                price = jsonObject1.getString("price");
                                rid = jsonObject1.getString("rid");


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            Log.d("rest name", "" + restaurant_name);
                            Log.d("imgname", "" + imgname);
                            Log.d("price", "" + price);
                            Log.d("category", ""+category);
                            Log.d("rid", ""+rid);

                            foodList.add(new ModelFood(restaurant_name, category, imgname, price,rid));
                        }

                        Log.d("foodlist", ""+foodList);
                        OrderAdapter orderAdapter = new OrderAdapter(OrderCart.this, foodList);
                        recyclerView1.setAdapter(orderAdapter);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.d("error: ", "hagg diya");
            }

        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        Toast.makeText(getApplicationContext(), "Back button is pressed", Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }

}


