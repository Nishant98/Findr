package com.example.sarah.nav;

public class getIp {

    public String ip = "http://192.168.43.158";

    public String getIp(){
        return  ip;
    }

}
